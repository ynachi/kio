#include <photon/photon.h>
#include <photon/fs/localfs.h>
#include <iostream>
#include <vector>
#include <fcntl.h>
#include <unistd.h>

int main() {
    if (photon::init(photon::INIT_EVENT_IOURING, photon::INIT_IO_NONE) != 0) {
        std::cerr << "failed photon init\n";
        return 1;
    }
    DEFER(photon::fini());

    auto file = photon::fs::open_localfile_adaptor("/tmp/test_photon_file.dat", O_RDWR | O_CREAT | O_TRUNC, 0644, photon::fs::ioengine_iouring);
    if (!file) {
        std::cerr << "failed open file\n";
        return 1;
    }
    DEFER({ delete file; unlink("/tmp/test_photon_file.dat"); });

    std::vector<char> buf(4096, 'A');
    ssize_t written = file->pwrite(buf.data(), buf.size(), 0);
    std::cout << "Written: " << written << " bytes\n";

    std::vector<char> read_buf(4096, 0);
    ssize_t read_bytes = file->pread(read_buf.data(), read_buf.size(), 0);
    std::cout << "Read: " << read_bytes << " bytes, first char: " << read_buf[0] << "\n";
    return 0;
}
