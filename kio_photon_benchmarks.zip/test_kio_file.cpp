#include "uring/core/io.h"
#include <iostream>
#include <vector>
#include <fcntl.h>
#include <unistd.h>

using namespace URing;

Task<void> test_write(IO& io, Fd& fd) {
    std::vector<std::byte> buf(4096, std::byte{0x42});
    auto res = co_await io.write(fd, std::span{buf}, 0);
    if (!res) {
        std::cerr << "write error: " << res.error().message() << std::endl;
        co_return {};
    }
    std::cout << "KIO Written: " << *res << " bytes\n";
    co_return {};
}

int main() {
    IO io(0);
    int raw_fd = ::open("/tmp/test_kio.dat", O_RDWR | O_CREAT | O_TRUNC, 0644);
    Fd fd{raw_fd};
    auto res = sync_wait(io, test_write(io, fd));
    ::unlink("/tmp/test_kio.dat");
    return 0;
}
