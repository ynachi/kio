#include "uring/core/io.h"
#include <iostream>
#include <vector>
#include <fcntl.h>
#include <unistd.h>
#include <sys/eventfd.h>
#include <random>

using namespace URing;

Task<void> worker_task(IO& io, Fd& fd, size_t task_id, size_t ops, size_t block_size, std::span<std::byte> buf, int ev_fd, std::atomic<size_t>& completed, size_t total_ops) {
    for (size_t i = 0; i < ops; ++i) {
        uint64_t offset = (i * block_size) % (16 * 1024 * 1024);
        auto res = co_await io.write(fd, buf.first(block_size), offset);
        if (!res) {
            std::cerr << "worker error\n";
            co_return {};
        }
    }
    if (completed.fetch_add(ops, std::memory_order_relaxed) + ops >= total_ops) {
        uint64_t one = 1;
        ::write(ev_fd, &one, sizeof(one));
    }
    co_return {};
}

Task<void> run_coordinator(IO& io, Fd& fd, size_t depth, size_t total_ops, size_t block_size, std::span<std::byte> buf) {
    int raw_ev = ::eventfd(0, EFD_NONBLOCK | EFD_CLOEXEC);
    Fd ev{raw_ev};
    std::atomic<size_t> completed{0};
    size_t ops_per_worker = total_ops / depth;

    for (size_t d = 0; d < depth; ++d) {
        io.schedule(worker_task(io, fd, d, ops_per_worker, block_size, buf, raw_ev, completed, total_ops));
    }

    uint64_t val = 0;
    auto res = co_await io.read(ev, std::as_writable_bytes(std::span{&val, 1}));
    std::cout << "All " << total_ops << " ops completed across " << depth << " concurrent tasks!\n";
    co_return {};
}

int main() {
    IO io(0);
    int raw_fd = ::open("/tmp/test_concurrent.dat", O_RDWR | O_CREAT | O_TRUNC, 0644);
    Fd fd{raw_fd};
    std::vector<std::byte> buf(4096, std::byte{'X'});

    auto res = sync_wait(io, run_coordinator(io, fd, 16, 1600, 4096, std::span{buf}));
    ::unlink("/tmp/test_concurrent.dat");
    return 0;
}
