import subprocess
import time
import json
import re
import os
import sys

KIO_BUILD_DIR = "/tmp/kio_photon_bench/kio/build"
PHOTON_DIR = "/tmp/kio_photon_bench"
BENCH_DIR = "/var/tmp"

def run_cmd(cmd, shell=True, check=True):
    res = subprocess.run(cmd, shell=shell, capture_output=True, text=True)
    if check and res.returncode != 0:
        raise RuntimeError(f"Command failed ({res.returncode}): {cmd}\nStdout: {res.stdout}\nStderr: {res.stderr}")
    return res

def drop_caches():
    try:
        subprocess.run("sudo sh -c 'sync; echo 3 > /proc/sys/vm/drop_caches'", shell=True, check=True)
    except Exception as e:
        print(f"Warning: could not drop caches: {e}")

def parse_wrk(output):
    rps_match = re.search(r"Requests/sec:\s+([\d\.]+)", output)
    rps = float(rps_match.group(1)) if rps_match else 0.0

    transfer_match = re.search(r"Transfer/sec:\s+([\d\.]+)(\w+)", output)
    transfer = f"{transfer_match.group(1)} {transfer_match.group(2)}" if transfer_match else "N/A"

    latency_match = re.search(r"Latency\s+([\d\.]+)(\w+)\s+([\d\.]+)(\w+)\s+([\d\.]+)(\w+)", output)
    avg_lat = f"{latency_match.group(1)}{latency_match.group(2)}" if latency_match else "N/A"
    stdev_lat = f"{latency_match.group(3)}{latency_match.group(4)}" if latency_match else "N/A"
    max_lat = f"{latency_match.group(5)}{latency_match.group(6)}" if latency_match else "N/A"

    return {
        "rps": rps,
        "avg_latency": avg_lat,
        "stdev_latency": stdev_lat,
        "max_latency": max_lat,
        "transfer": transfer
    }

def parse_oha(output):
    rps_match = re.search(r"Requests/sec:\s+([\d\.]+)", output)
    rps = float(rps_match.group(1)) if rps_match else 0.0

    avg_match = re.search(r"Average:\s+([\d\.]+)\s+ms", output)
    avg_ms = float(avg_match.group(1)) if avg_match else 0.0

    def get_pct(pct_str):
        m = re.search(rf"{pct_str} in ([\d\.]+) ms", output)
        return float(m.group(1)) if m else 0.0

    return {
        "rps": rps,
        "avg_ms": avg_ms,
        "p50_ms": get_pct("50.00%"),
        "p90_ms": get_pct("90.00%"),
        "p99_ms": get_pct("99.00%"),
        "p999_ms": get_pct("99.90%")
    }

def run_server_bench(engine, mode, tool, duration, threads, conns, port=8895):
    subprocess.run(f"fuser -k -9 {port}/tcp 2>/dev/null", shell=True)
    time.sleep(0.5)

    if engine == "kio":
        dispatch_flag = "" if mode == "dispatch" else "--no-dispatch"
        server_cmd = f"{KIO_BUILD_DIR}/kio_http_bench --port={port} --workers=4 {dispatch_flag}"
    else:
        dispatch_flag = "--dispatch" if mode == "dispatch" else "--no-dispatch"
        server_cmd = f"{PHOTON_DIR}/photon_http_bench --port={port} --workers=4 {dispatch_flag}"

    proc = subprocess.Popen(server_cmd, shell=True, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
    
    ready = False
    for _ in range(50):
        time.sleep(0.1)
        res = subprocess.run(f"curl -s http://127.0.0.1:{port}/", shell=True, capture_output=True, text=True)
        if "Hello, World!" in res.stdout:
            ready = True
            break
    if not ready:
        proc.kill()
        raise RuntimeError(f"Server {engine} ({mode}) failed to start on port {port}")

    result = {}
    try:
        if tool == "wrk":
            cmd = f"wrk -t{threads} -c{conns} -d{duration}s --latency http://127.0.0.1:{port}/"
            res = run_cmd(cmd)
            result = parse_wrk(res.stdout)
        elif tool == "oha":
            cmd = f"oha -z {duration}s -c {conns} --no-tui http://127.0.0.1:{port}/"
            res = run_cmd(cmd)
            result = parse_oha(res.stdout)
    finally:
        proc.terminate()
        try:
            proc.wait(timeout=2)
        except subprocess.TimeoutExpired:
            proc.kill()
            proc.wait()
        subprocess.run(f"fuser -k -9 {port}/tcp 2>/dev/null", shell=True)
        time.sleep(0.5)

    return result

def run_file_test(engine, test, bytes_total, block, depth=1, ops=65536):
    bin_name = "kio_disk_bench" if engine == "kio" else "photon_disk_bench"
    path = f"{BENCH_DIR}/{engine}_bench.dat"
    cmd = f"{PHOTON_DIR}/{bin_name} --test={test} --bytes={bytes_total} --block={block} --depth={depth} --ops={ops} --path={path}"
    
    if "read" in test:
        size_mb = bytes_total // (1024 * 1024)
        if not os.path.exists(path) or os.path.getsize(path) < bytes_total:
            subprocess.run(f"dd if=/dev/urandom of={path} bs=1M count={size_mb} status=none", shell=True)
        drop_caches()

    res = run_cmd(cmd)
    try:
        data = json.loads(res.stdout.strip())
    except Exception as e:
        raise RuntimeError(f"Failed to parse JSON from {cmd}: {res.stdout}")
    
    return data

def main():
    print("==========================================================")
    print("Starting KIO vs Alibaba Photon Comprehensive Benchmark")
    print("==========================================================")

    all_results = {"file_io": [], "network_io": []}

    file_tests = [
        # (test, bytes, block, depth, ops, label)
        ("seq_write", 512 * 1024 * 1024, 4096, 1, 0, "Seq Write 4 KiB"),
        ("seq_write", 512 * 1024 * 1024, 65536, 1, 0, "Seq Write 64 KiB"),
        ("seq_write", 512 * 1024 * 1024, 1048576, 1, 0, "Seq Write 1 MiB"),
        ("seq_read", 512 * 1024 * 1024, 4096, 1, 0, "Seq Read 4 KiB"),
        ("seq_read", 512 * 1024 * 1024, 65536, 1, 0, "Seq Read 64 KiB"),
        ("seq_read", 512 * 1024 * 1024, 1048576, 1, 0, "Seq Read 1 MiB"),
        ("rand_read", 256 * 1024 * 1024, 4096, 1, 65536, "Rand Read 4 KiB (Depth 1)"),
        ("rand_read", 256 * 1024 * 1024, 4096, 16, 65536, "Rand Read 4 KiB (Depth 16)"),
        ("rand_read", 256 * 1024 * 1024, 4096, 64, 65536, "Rand Read 4 KiB (Depth 64)"),
        ("rand_write", 256 * 1024 * 1024, 4096, 1, 65536, "Rand Write 4 KiB (Depth 1)"),
        ("rand_write", 256 * 1024 * 1024, 4096, 16, 65536, "Rand Write 4 KiB (Depth 16)"),
        ("rand_write", 256 * 1024 * 1024, 4096, 64, 65536, "Rand Write 4 KiB (Depth 64)"),
        ("direct_write", 256 * 1024 * 1024, 4096, 1, 0, "O_DIRECT Write 4 KiB"),
        ("direct_read", 256 * 1024 * 1024, 4096, 1, 0, "O_DIRECT Read 4 KiB"),
    ]

    print("\n--- SECTION 1: File I/O Benchmarks (NVMe /var/tmp) ---")
    for test, b_total, block, depth, ops, label in file_tests:
        print(f"Running {label}...")
        kio_runs = []
        photon_runs = []
        for r in range(3):
            kio_res = run_file_test("kio", test, b_total, block, depth, ops)
            kio_runs.append(kio_res["mibs"])
            
            photon_res = run_file_test("photon", test, b_total, block, depth, ops)
            photon_runs.append(photon_res["mibs"])
        
        kio_runs.sort()
        photon_runs.sort()
        kio_med = kio_runs[1]
        photon_med = photon_runs[1]
        diff_pct = ((kio_med - photon_med) / photon_med) * 100.0 if photon_med > 0 else 0.0

        entry = {
            "label": label,
            "test": test,
            "block": block,
            "depth": depth,
            "kio_mibs": kio_med,
            "photon_mibs": photon_med,
            "diff_pct": diff_pct
        }
        all_results["file_io"].append(entry)
        print(f"  -> KIO: {kio_med:.2f} MiB/s | Photon: {photon_med:.2f} MiB/s | KIO vs Photon: {diff_pct:+.1f}%")

    # Clean up file dat
    subprocess.run(f"rm -f {BENCH_DIR}/kio_bench.dat {BENCH_DIR}/photon_bench.dat", shell=True)

    print("\n--- SECTION 2: Network I/O Benchmarks (HTTP 4 workers) ---")
    net_configs = [
        # (mode, tool, duration, threads, conns, label)
        ("reuseport", "wrk", 10, 4, 100, "wrk 100c SO_REUSEPORT"),
        ("reuseport", "wrk", 10, 8, 500, "wrk 500c SO_REUSEPORT"),
        ("reuseport", "wrk", 10, 8, 1000, "wrk 1000c SO_REUSEPORT"),
        ("reuseport", "oha", 10, 4, 100, "oha 100c SO_REUSEPORT"),
        ("reuseport", "oha", 10, 8, 500, "oha 500c SO_REUSEPORT"),
        ("dispatch", "wrk", 10, 4, 100, "wrk 100c Dispatch"),
        ("dispatch", "wrk", 10, 8, 500, "wrk 500c Dispatch"),
        ("dispatch", "oha", 10, 4, 100, "oha 100c Dispatch"),
    ]

    for mode, tool, dur, th, conns, label in net_configs:
        print(f"Running Network Benchmark: {label}...")
        kio_res = run_server_bench("kio", mode, tool, dur, th, conns)
        photon_res = run_server_bench("photon", mode, tool, dur, th, conns)
        
        diff_pct = ((kio_res["rps"] - photon_res["rps"]) / photon_res["rps"]) * 100.0 if photon_res["rps"] > 0 else 0.0
        
        entry = {
            "label": label,
            "mode": mode,
            "tool": tool,
            "conns": conns,
            "kio": kio_res,
            "photon": photon_res,
            "diff_pct": diff_pct
        }
        all_results["network_io"].append(entry)
        print(f"  -> KIO: {kio_res['rps']:.0f} req/s | Photon: {photon_res['rps']:.0f} req/s | KIO vs Photon: {diff_pct:+.1f}%")

    with open("/tmp/kio_photon_bench/benchmark_results.json", "w") as f:
        json.dump(all_results, f, indent=2)
    print("\nAll benchmarks finished successfully! Results saved to /tmp/kio_photon_bench/benchmark_results.json")

if __name__ == "__main__":
    main()
