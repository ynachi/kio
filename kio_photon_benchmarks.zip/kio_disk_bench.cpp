#include "uring/core/io.h"
#include <chrono>
#include <cstdint>
#include <cstdlib>
#include <cstring>
#include <fcntl.h>
#include <iostream>
#include <random>
#include <span>
#include <string>
#include <string_view>
#include <sys/eventfd.h>
#include <unistd.h>
#include <vector>

using namespace URing;
using Clock = std::chrono::steady_clock;

struct Config {
    std::string test = "seq_write";
    std::string path = "/var/tmp/kio_bench.dat";
    uint64_t bytes = 512ull * 1024ull * 1024ull;
    size_t block = 4096;
    size_t depth = 1;
    size_t ops = 65536;
};

uint64_t parse_u64(std::string_view s) {
    uint64_t mult = 1;
    if (!s.empty()) {
        char c = s.back();
        if (c == 'k' || c == 'K') { mult = 1024; s.remove_suffix(1); }
        else if (c == 'm' || c == 'M') { mult = 1024 * 1024; s.remove_suffix(1); }
        else if (c == 'g' || c == 'G') { mult = 1024 * 1024 * 1024; s.remove_suffix(1); }
    }
    return std::stoull(std::string{s}) * mult;
}

Config parse_args(int argc, char** argv) {
    Config cfg;
    for (int i = 1; i < argc; ++i) {
        std::string_view a = argv[i];
        if (a.starts_with("--test=")) cfg.test = a.substr(7);
        else if (a.starts_with("--path=")) cfg.path = a.substr(7);
        else if (a.starts_with("--bytes=")) cfg.bytes = parse_u64(a.substr(8));
        else if (a.starts_with("--block=")) cfg.block = parse_u64(a.substr(8));
        else if (a.starts_with("--depth=")) cfg.depth = parse_u64(a.substr(8));
        else if (a.starts_with("--ops=")) cfg.ops = parse_u64(a.substr(6));
    }
    return cfg;
}

Task<void> run_seq_write(IO& io, Fd& fd, uint64_t total_bytes, size_t block_size, std::span<const std::byte> buf) {
    uint64_t offset = 0;
    while (offset < total_bytes) {
        size_t len = std::min<uint64_t>(block_size, total_bytes - offset);
        auto res = co_await io.write(fd, buf.first(len), static_cast<off_t>(offset));
        if (!res || *res <= 0) {
            throw std::runtime_error("kio seq write failed");
        }
        offset += len;
    }
    co_return {};
}

Task<void> run_seq_read(IO& io, Fd& fd, uint64_t total_bytes, size_t block_size, std::span<std::byte> buf) {
    uint64_t offset = 0;
    while (offset < total_bytes) {
        size_t len = std::min<uint64_t>(block_size, total_bytes - offset);
        auto res = co_await io.read(fd, buf.first(len), static_cast<off_t>(offset));
        if (!res || *res <= 0) {
            throw std::runtime_error("kio seq read failed");
        }
        offset += len;
    }
    co_return {};
}

Task<void> concurrent_worker(IO& io, Fd& fd, size_t ops, size_t block_size, uint64_t file_size,
                             bool is_write, std::span<std::byte> buf, int ev_fd,
                             std::atomic<size_t>& completed, size_t total_ops, uint64_t seed) {
    std::mt19937_64 rng(seed);
    const uint64_t max_blocks = file_size > block_size ? (file_size - block_size) / block_size : 1;

    for (size_t i = 0; i < ops; ++i) {
        uint64_t offset = (rng() % max_blocks) * block_size;
        if (is_write) {
            auto res = co_await io.write(fd, buf.first(block_size), static_cast<off_t>(offset));
            if (!res) throw std::runtime_error("kio write failed");
        } else {
            auto res = co_await io.read(fd, buf.first(block_size), static_cast<off_t>(offset));
            if (!res) throw std::runtime_error("kio read failed");
        }
    }

    if (completed.fetch_add(ops, std::memory_order_relaxed) + ops >= total_ops) {
        uint64_t one = 1;
        ssize_t w = ::write(ev_fd, &one, sizeof(one));
        (void)w;
    }
    co_return {};
}

Task<void> run_concurrent(IO& io, Fd& fd, size_t depth, size_t total_ops, size_t block_size,
                          uint64_t file_size, bool is_write, std::span<std::byte> buf) {
    int raw_ev = ::eventfd(0, EFD_NONBLOCK | EFD_CLOEXEC);
    Fd ev{raw_ev};
    std::atomic<size_t> completed{0};
    size_t ops_per_worker = total_ops / depth;

    for (size_t d = 0; d < depth; ++d) {
        io.schedule(concurrent_worker(io, fd, ops_per_worker, block_size, file_size,
                                      is_write, buf, raw_ev, completed, total_ops, 1337 + d * 997));
    }

    uint64_t val = 0;
    auto res = co_await io.read(ev, std::as_writable_bytes(std::span{&val, 1}));
    (void)res;
    co_return {};
}

int main(int argc, char** argv) {
    try {
        Config cfg = parse_args(argc, argv);
        IO io(0);

        void* raw_buf = nullptr;
        if (::posix_memalign(&raw_buf, 4096, cfg.block) != 0) {
            throw std::runtime_error("posix_memalign failed");
        }
        std::memset(raw_buf, 'Z', cfg.block);
        std::span<std::byte> buf_span(reinterpret_cast<std::byte*>(raw_buf), cfg.block);

        int flags = 0;
        bool is_direct = (cfg.test == "direct_write" || cfg.test == "direct_read");
        bool is_write = (cfg.test == "seq_write" || cfg.test == "rand_write" || cfg.test == "direct_write");

        if (is_write) {
            flags = O_RDWR | O_CREAT;
        } else {
            flags = O_RDONLY;
        }
        if (is_direct) {
            flags |= O_DIRECT;
        }

        int raw_fd = ::open(cfg.path.c_str(), flags, 0644);
        if (raw_fd < 0) {
            throw std::runtime_error("failed to open: " + cfg.path + ": " + std::strerror(errno));
        }
        Fd fd{raw_fd};

        auto start = Clock::now();
        uint64_t ops_done = 0;
        uint64_t bytes_done = 0;

        if (cfg.test == "seq_write" || cfg.test == "direct_write") {
            ops_done = (cfg.bytes + cfg.block - 1) / cfg.block;
            bytes_done = cfg.bytes;
            sync_wait(io, run_seq_write(io, fd, cfg.bytes, cfg.block, buf_span));
        } else if (cfg.test == "seq_read" || cfg.test == "direct_read") {
            ops_done = (cfg.bytes + cfg.block - 1) / cfg.block;
            bytes_done = cfg.bytes;
            sync_wait(io, run_seq_read(io, fd, cfg.bytes, cfg.block, buf_span));
        } else if (cfg.test == "rand_write") {
            ops_done = cfg.ops;
            bytes_done = cfg.ops * cfg.block;
            sync_wait(io, run_concurrent(io, fd, cfg.depth, cfg.ops, cfg.block, cfg.bytes, true, buf_span));
        } else if (cfg.test == "rand_read") {
            ops_done = cfg.ops;
            bytes_done = cfg.ops * cfg.block;
            sync_wait(io, run_concurrent(io, fd, cfg.depth, cfg.ops, cfg.block, cfg.bytes, false, buf_span));
        }

        auto end = Clock::now();
        double elapsed_sec = std::chrono::duration<double>(end - start).count();
        double iops = (double)ops_done / elapsed_sec;
        double mibs = ((double)bytes_done / (1024.0 * 1024.0)) / elapsed_sec;

        std::cout << "{\"engine\": \"kio\", \"test\": \"" << cfg.test << "\", "
                  << "\"block_size\": " << cfg.block << ", "
                  << "\"queue_depth\": " << cfg.depth << ", "
                  << "\"bytes\": " << bytes_done << ", "
                  << "\"ops\": " << ops_done << ", "
                  << "\"elapsed_sec\": " << elapsed_sec << ", "
                  << "\"iops\": " << iops << ", "
                  << "\"mibs\": " << mibs << "}" << std::endl;

        std::free(raw_buf);
    } catch (const std::exception& e) {
        std::cerr << "Error: " << e.what() << std::endl;
        return 1;
    }
    return 0;
}
