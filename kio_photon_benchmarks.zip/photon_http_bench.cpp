#include <atomic>
#include <charconv>
#include <chrono>
#include <csignal>
#include <iostream>
#include <string_view>
#include <thread>
#include <vector>

#include <photon/photon.h>
#include <photon/common/alog.h>
#include <photon/net/socket.h>
#include <photon/thread/thread.h>
#include <photon/thread/thread11.h>
#include <photon/thread/workerpool.h>
#include <netinet/tcp.h>

namespace {
std::atomic_bool g_stop_requested{false};

constexpr std::string_view kHttpResponse =
    "HTTP/1.1 200 OK\r\n"
    "Content-Type: text/plain\r\n"
    "Content-Length: 13\r\n"
    "Connection: keep-alive\r\n"
    "\r\n"
    "Hello, World!";

struct Options {
    uint16_t port = 8082;
    size_t workers = 4;
    bool dispatch = false;
    bool use_iouring_engine = true;
};

void signal_handler(int) {
    g_stop_requested.store(true, std::memory_order_relaxed);
}

uint64_t parse_u64(std::string_view text) {
    uint64_t value = 0;
    const auto* first = text.data();
    const auto* last = text.data() + text.size();
    const auto [ptr, ec] = std::from_chars(first, last, value);
    if (ec != std::errc{} || ptr != last) {
        throw std::invalid_argument("invalid integer argument");
    }
    return value;
}

Options parse_args(int argc, char** argv) {
    Options opts;
    for (int i = 1; i < argc; ++i) {
        std::string_view arg = argv[i];
        auto value_for = [&](std::string_view name) -> std::string_view {
            if (!arg.starts_with(name) || arg.size() <= name.size() || arg[name.size()] != '=') {
                return {};
            }
            return arg.substr(name.size() + 1);
        };

        if (auto value = value_for("--port"); !value.empty()) {
            opts.port = static_cast<uint16_t>(parse_u64(value));
        } else if (auto value = value_for("--workers"); !value.empty()) {
            opts.workers = static_cast<size_t>(parse_u64(value));
        } else if (arg == "--dispatch") {
            opts.dispatch = true;
        } else if (arg == "--no-dispatch") {
            opts.dispatch = false;
        } else if (arg == "--epoll") {
            opts.use_iouring_engine = false;
        } else {
            throw std::invalid_argument("unknown argument: " + std::string(arg));
        }
    }
    return opts;
}

void handle_client(photon::net::ISocketStream* sock) {
    char buf[4096];
    while (!g_stop_requested.load(std::memory_order_relaxed)) {
        ssize_t ret = sock->recv(buf, sizeof(buf));
        if (ret <= 0) {
            break;
        }
        ssize_t sent = sock->write(kHttpResponse.data(), kHttpResponse.size());
        if (sent != static_cast<ssize_t>(kHttpResponse.size())) {
            break;
        }
    }
}

void run_reuseport_worker(uint16_t port, bool use_iouring) {
    int ev_engine = use_iouring ? photon::INIT_EVENT_IOURING : photon::INIT_EVENT_EPOLL;
    if (photon::init(ev_engine, photon::INIT_IO_NONE) != 0) {
        std::cerr << "failed to init photon\n";
        return;
    }
    DEFER(photon::fini());

    auto server = photon::net::new_tcp_socket_server();
    if (!server) {
        std::cerr << "failed to create tcp server\n";
        return;
    }
    DEFER(delete server);

    server->setsockopt<int>(SOL_SOCKET, SO_REUSEADDR, 1);
    server->setsockopt<int>(SOL_SOCKET, SO_REUSEPORT, 1);
    server->setsockopt<int>(IPPROTO_TCP, TCP_NODELAY, 1);

    if (server->bind_v4any(port) != 0) {
        std::cerr << "failed to bind port " << port << "\n";
        return;
    }
    if (server->listen(4096) != 0) {
        std::cerr << "failed to listen\n";
        return;
    }

    while (!g_stop_requested.load(std::memory_order_relaxed)) {
        auto* stream = server->accept();
        if (!stream) {
            if (g_stop_requested.load(std::memory_order_relaxed)) break;
            photon::thread_usleep(1000);
            continue;
        }
        photon::thread_create11([stream] {
            handle_client(stream);
            delete stream;
        });
    }
}

void run_dispatch_server(uint16_t port, size_t workers, bool use_iouring) {
    int ev_engine = use_iouring ? photon::INIT_EVENT_IOURING : photon::INIT_EVENT_EPOLL;
    if (photon::init(ev_engine, photon::INIT_IO_NONE) != 0) {
        std::cerr << "failed to init photon\n";
        return;
    }
    DEFER(photon::fini());

    photon::WorkPool wp(workers, ev_engine, photon::INIT_IO_NONE, 128 * 1024);

    auto server = photon::net::new_tcp_socket_server();
    if (!server) {
        std::cerr << "failed to create tcp server\n";
        return;
    }
    DEFER(delete server);

    server->setsockopt<int>(SOL_SOCKET, SO_REUSEADDR, 1);
    server->setsockopt<int>(IPPROTO_TCP, TCP_NODELAY, 1);

    if (server->bind_v4any(port) != 0) {
        std::cerr << "failed to bind port " << port << "\n";
        return;
    }
    if (server->listen(4096) != 0) {
        std::cerr << "failed to listen\n";
        return;
    }

    while (!g_stop_requested.load(std::memory_order_relaxed)) {
        auto* stream = server->accept();
        if (!stream) {
            if (g_stop_requested.load(std::memory_order_relaxed)) break;
            photon::thread_usleep(1000);
            continue;
        }
        wp.async_call(new auto([stream] {
            handle_client(stream);
            delete stream;
        }));
    }
}

} // namespace

int main(int argc, char** argv) {
    try {
        const Options opts = parse_args(argc, argv);
        std::signal(SIGINT, signal_handler);
        std::signal(SIGTERM, signal_handler);
        std::signal(SIGPIPE, SIG_IGN);
        set_log_output_level(ALOG_FATAL);

        std::cout << "photon_http_bench listening on port " << opts.port
                  << " workers=" << opts.workers
                  << " dispatch=" << (opts.dispatch ? "true" : "false")
                  << " engine=" << (opts.use_iouring_engine ? "io_uring" : "epoll") << std::endl;

        if (opts.dispatch) {
            run_dispatch_server(opts.port, opts.workers, opts.use_iouring_engine);
        } else {
            std::vector<std::jthread> threads;
            threads.reserve(opts.workers);
            for (size_t i = 0; i < opts.workers; ++i) {
                threads.emplace_back([&opts] {
                    run_reuseport_worker(opts.port, opts.use_iouring_engine);
                });
            }
            while (!g_stop_requested.load(std::memory_order_relaxed)) {
                std::this_thread::sleep_for(std::chrono::milliseconds(100));
            }
            for (auto& th : threads) {
                if (th.joinable()) th.join();
            }
        }
    } catch (const std::exception& e) {
        std::cerr << "error: " << e.what() << '\n';
        return 1;
    }
    return 0;
}
