#include <photon/photon.h>
#include <photon/common/alog.h>
#include <photon/fs/localfs.h>
#include <photon/thread/thread.h>
#include <photon/thread/thread11.h>
#include <chrono>
#include <cstdint>
#include <cstdlib>
#include <cstring>
#include <fcntl.h>
#include <iostream>
#include <random>
#include <string>
#include <string_view>
#include <unistd.h>
#include <vector>

using Clock = std::chrono::steady_clock;

struct Config {
    std::string test = "seq_write";
    std::string path = "/var/tmp/photon_bench.dat";
    uint64_t bytes = 512ull * 1024ull * 1024ull;
    size_t block = 4096;
    size_t depth = 1;
    size_t ops = 65536;
};

uint64_t parse_u64(std::string_view s) {
    uint64_t mult = 1;
    if (!s.empty()) {
        char c = s.back();
        if (c == 'k' || c == 'K') { mult = 1024; s.remove_suffix(1); }
        else if (c == 'm' || c == 'M') { mult = 1024 * 1024; s.remove_suffix(1); }
        else if (c == 'g' || c == 'G') { mult = 1024 * 1024 * 1024; s.remove_suffix(1); }
    }
    return std::stoull(std::string{s}) * mult;
}

Config parse_args(int argc, char** argv) {
    Config cfg;
    for (int i = 1; i < argc; ++i) {
        std::string_view a = argv[i];
        if (a.starts_with("--test=")) cfg.test = a.substr(7);
        else if (a.starts_with("--path=")) cfg.path = a.substr(7);
        else if (a.starts_with("--bytes=")) cfg.bytes = parse_u64(a.substr(8));
        else if (a.starts_with("--block=")) cfg.block = parse_u64(a.substr(8));
        else if (a.starts_with("--depth=")) cfg.depth = parse_u64(a.substr(8));
        else if (a.starts_with("--ops=")) cfg.ops = parse_u64(a.substr(6));
    }
    return cfg;
}

void run_seq_write(photon::fs::IFile* file, uint64_t total_bytes, size_t block_size, const void* buf) {
    uint64_t offset = 0;
    while (offset < total_bytes) {
        size_t len = std::min<uint64_t>(block_size, total_bytes - offset);
        ssize_t ret = file->pwrite(buf, len, static_cast<off_t>(offset));
        if (ret != static_cast<ssize_t>(len)) {
            throw std::runtime_error("photon seq write failed");
        }
        offset += len;
    }
}

void run_seq_read(photon::fs::IFile* file, uint64_t total_bytes, size_t block_size, void* buf) {
    uint64_t offset = 0;
    while (offset < total_bytes) {
        size_t len = std::min<uint64_t>(block_size, total_bytes - offset);
        ssize_t ret = file->pread(buf, len, static_cast<off_t>(offset));
        if (ret != static_cast<ssize_t>(len)) {
            throw std::runtime_error("photon seq read failed");
        }
        offset += len;
    }
}

void concurrent_worker(photon::fs::IFile* file, size_t ops, size_t block_size, uint64_t file_size,
                       bool is_write, void* buf, photon::semaphore* sem, uint64_t seed) {
    std::mt19937_64 rng(seed);
    const uint64_t max_blocks = file_size > block_size ? (file_size - block_size) / block_size : 1;

    for (size_t i = 0; i < ops; ++i) {
        uint64_t offset = (rng() % max_blocks) * block_size;
        if (is_write) {
            ssize_t ret = file->pwrite(buf, block_size, static_cast<off_t>(offset));
            if (ret != static_cast<ssize_t>(block_size)) {
                std::cerr << "photon pwrite error: " << ret << " errno: " << errno << std::endl;
                break;
            }
        } else {
            ssize_t ret = file->pread(buf, block_size, static_cast<off_t>(offset));
            if (ret != static_cast<ssize_t>(block_size)) {
                std::cerr << "photon pread error: " << ret << " errno: " << errno << std::endl;
                break;
            }
        }
    }
    sem->signal(1);
}

void run_concurrent(photon::fs::IFile* file, size_t depth, size_t total_ops, size_t block_size,
                    uint64_t file_size, bool is_write, void* base_buf) {
    photon::semaphore sem(0);
    size_t ops_per_worker = total_ops / depth;

    for (size_t d = 0; d < depth; ++d) {
        photon::thread_create11(concurrent_worker, file, ops_per_worker, block_size, file_size,
                                is_write, base_buf, &sem, 1337 + d * 997);
    }

    sem.wait(depth);
}

int main(int argc, char** argv) {
    try {
        Config cfg = parse_args(argc, argv);
        set_log_output_level(ALOG_FATAL);

        if (photon::init(photon::INIT_EVENT_IOURING, photon::INIT_IO_NONE) != 0) {
            std::cerr << "photon init failed" << std::endl;
            return 1;
        }
        DEFER(photon::fini());

        void* raw_buf = nullptr;
        if (::posix_memalign(&raw_buf, 4096, cfg.block) != 0) {
            throw std::runtime_error("posix_memalign failed");
        }
        std::memset(raw_buf, 'Z', cfg.block);

        int flags = 0;
        bool is_direct = (cfg.test == "direct_write" || cfg.test == "direct_read");
        bool is_write = (cfg.test == "seq_write" || cfg.test == "rand_write" || cfg.test == "direct_write");

        if (is_write) {
            flags = O_RDWR | O_CREAT;
        } else {
            flags = O_RDONLY;
        }
        if (is_direct) {
            flags |= O_DIRECT;
        }

        auto file = photon::fs::open_localfile_adaptor(cfg.path.c_str(), flags, 0644, photon::fs::ioengine_iouring);
        if (!file) {
            throw std::runtime_error("failed to open: " + cfg.path + ": " + std::strerror(errno));
        }
        DEFER(delete file);

        auto start = Clock::now();
        uint64_t ops_done = 0;
        uint64_t bytes_done = 0;

        if (cfg.test == "seq_write" || cfg.test == "direct_write") {
            ops_done = (cfg.bytes + cfg.block - 1) / cfg.block;
            bytes_done = cfg.bytes;
            run_seq_write(file, cfg.bytes, cfg.block, raw_buf);
        } else if (cfg.test == "seq_read" || cfg.test == "direct_read") {
            ops_done = (cfg.bytes + cfg.block - 1) / cfg.block;
            bytes_done = cfg.bytes;
            run_seq_read(file, cfg.bytes, cfg.block, raw_buf);
        } else if (cfg.test == "rand_write") {
            ops_done = cfg.ops;
            bytes_done = cfg.ops * cfg.block;
            run_concurrent(file, cfg.depth, cfg.ops, cfg.block, cfg.bytes, true, raw_buf);
        } else if (cfg.test == "rand_read") {
            ops_done = cfg.ops;
            bytes_done = cfg.ops * cfg.block;
            run_concurrent(file, cfg.depth, cfg.ops, cfg.block, cfg.bytes, false, raw_buf);
        }

        auto end = Clock::now();
        double elapsed_sec = std::chrono::duration<double>(end - start).count();
        double iops = (double)ops_done / elapsed_sec;
        double mibs = ((double)bytes_done / (1024.0 * 1024.0)) / elapsed_sec;

        std::cout << "{\"engine\": \"photon\", \"test\": \"" << cfg.test << "\", "
                  << "\"block_size\": " << cfg.block << ", "
                  << "\"queue_depth\": " << cfg.depth << ", "
                  << "\"bytes\": " << bytes_done << ", "
                  << "\"ops\": " << ops_done << ", "
                  << "\"elapsed_sec\": " << elapsed_sec << ", "
                  << "\"iops\": " << iops << ", "
                  << "\"mibs\": " << mibs << "}" << std::endl;

        std::free(raw_buf);
    } catch (const std::exception& e) {
        std::cerr << "Error: " << e.what() << std::endl;
        return 1;
    }
    return 0;
}
